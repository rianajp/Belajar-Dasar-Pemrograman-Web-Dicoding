Nama : Rian Ajie Pangestu
Email Dicoding : rianajiep12@gmai.com
Submission: Tugas Akhir Membuat Website

Program Bangkit 2023 kelas CC-55

Website portofolio MY TRPL sederhana dengan menggunakan HTML, dan CSS.
Website ini mengenai portofolio dari prodi TRPL yaitu program studi yang ada di kampus saya.